var typed= new typed(".text",{
    Strings:["Frontend Developer" , "Youtuber", "Web Developer"],
    typeSpped: 100,
    backSpeed:100,
    backDelay:1000,
    loop:true
});